package com.example.unitconvertorapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    //Declaring Widgets
    EditText editTextNumber1, editTextNumber2, editTextNumber3;
    TextView Gms, Ibs, Meters, Kms, Inch, F, textView1,  textView4,  textView8;
    Button textView2, textView3, textView5, textView6, textView7, textView9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Instantiating Widgets
        Gms = findViewById(R.id.Gms);
        Ibs = findViewById(R.id.Ibs);
        Meters = findViewById(R.id.Meters);
        Kms = findViewById(R.id.Kms);
        Inch = findViewById(R.id.Inch);
        F = findViewById(R.id.F);
        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);
        textView4 = findViewById(R.id.textView4);
        textView5 = findViewById(R.id.textView5);
        textView6 = findViewById(R.id.textView6);
        textView7 = findViewById(R.id.textView7);
        textView8 = findViewById(R.id.textView8);
        textView9 = findViewById(R.id.textView9);
        editTextNumber1 = findViewById(R.id.editTextNumber1);
        editTextNumber2 = findViewById(R.id.editTextNumber2);
        editTextNumber3 = findViewById(R.id.editTextNumber3);


        // Adding the click event

        textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Converting from Kgms to Gms
                KilogmsToGms();

            }
        });

        textView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Converting from Kgms to Ibs
                KilogmsToIbs();

            }
        });
        textView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Converting from Cms to meter
                CmsToMeter();
            }
        });

        textView6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Converting from Cms to kilometer
                CmsToKiloMeter();
            }
        });

        textView7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Converting from Cms to inch
                CmsToInch();
            }
        });

        textView9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Converting from C to F
                CelsiusToFahrenheit();
            }
        });
    }



    private void KilogmsToGms() {
        String valueKiloGms = editTextNumber1.getText().toString();
        double kilo1 = Double.parseDouble(valueKiloGms);
        double gmValue = kilo1*1000;
        Gms.setText(""+ gmValue);
    }
    private void KilogmsToIbs() {
        String valueKiloGms = editTextNumber1.getText().toString();
        double kilo2 = Double.parseDouble(valueKiloGms);
        double IbsValue = kilo2*2.205;
        Ibs.setText(""+ IbsValue);
    }
    private void CmsToMeter() {
        String valueCms = editTextNumber2.getText().toString();
        double Cm1 = Double.parseDouble(valueCms);
        double MeterValue = Cm1*0.01;
        Meters.setText(""+ MeterValue);
    }
    private void CmsToKiloMeter() {
        String valueCms = editTextNumber2.getText().toString();
        double Cm2 = Double.parseDouble(valueCms);
        double KmsValue = Cm2/100000;
        Kms.setText(""+ KmsValue);
    }

    private void CmsToInch() {
        String valueCms = editTextNumber2.getText().toString();
        double Cm3 = Double.parseDouble(valueCms);
        double InchValue = Cm3*0.3937;
        Inch.setText(""+ InchValue);
    }

    private void CelsiusToFahrenheit() {
        String valueCelsius = editTextNumber3.getText().toString();
        double Celsius = Double.parseDouble(valueCelsius);
        double Fahrenheit = Celsius*1.8000 + 32.00;
        F.setText(""+ Fahrenheit);
    }


}