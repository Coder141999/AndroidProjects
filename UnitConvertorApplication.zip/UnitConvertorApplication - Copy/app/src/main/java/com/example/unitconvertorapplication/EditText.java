package com.example.unitconvertorapplication;

public interface EditText {
}
